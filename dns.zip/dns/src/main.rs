use hickory_server::{
    authority::MessageResponseBuilder,
    proto::op::Header,
    server::{Request, RequestHandler, ResponseHandler, ResponseInfo, ServerFuture},
};
use hickory_resolver::{
    config::{ResolverConfig, ResolverOpts},
    AsyncResolver,
};
use tokio::net::UdpSocket;
use std::sync::Arc;
use tokio::sync::RwLock;

use axum::{
    routing::get,
    Router,
    extract::State,
    Json,
};
use tower_http::{services::ServeDir, cors::CorsLayer};
use serde::{Serialize, Deserialize};
use chrono::Local;
use std::str::FromStr;

// --- Modeller ---
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DnsLog {
    pub id: usize,
    pub timestamp: String,
    pub domain: String,
    pub record_type: String,
    pub status: String,
}

type SharedState = Arc<RwLock<Vec<DnsLog>>>;

async fn get_reports(State(state): State<SharedState>) -> Json<Vec<DnsLog>> {
    let logs = state.read().await;
    let mut reversed: Vec<DnsLog> = logs.clone();
    reversed.reverse();
    Json(reversed)
}

#[derive(Clone)]
struct DnsInspector {
    resolver: AsyncResolver<hickory_resolver::name_server::TokioConnectionProvider>,
    state: SharedState,
}

impl DnsInspector {
    fn new(state: SharedState) -> Self {
        let config = ResolverConfig::cloudflare_https();
        let mut opts = ResolverOpts::default();
        opts.use_hosts_file = false;
        
        // As of 0.24 AsyncResolver::tokio does return the resolver directly (no Result)
        let resolver = AsyncResolver::tokio(config, opts);
        Self { resolver, state }
    }
}

#[async_trait::async_trait]
impl RequestHandler for DnsInspector {
    async fn handle_request<R: ResponseHandler>(
        &self,
        request: &Request,
        mut response_handle: R,
    ) -> ResponseInfo {
        let query = request.query();
        let name_str = query.name().to_string();
        let record_type = query.query_type();
        
        println!("🕵️ [Müfettiş Yakaladı] İstek: {} ---> Tipi: {:?}", name_str, record_type);
        
        // Convert to standard Name for resolver
        let qname = hickory_resolver::Name::from_str(&name_str).unwrap();
        let resolve_result = self.resolver.lookup(qname, record_type).await;
        
        let status = if resolve_result.is_ok() { "Yakalandı & Çözüldü" } else { "Çözümleme Hatası" };
        
        {
            let mut logs = self.state.write().await;
            let id = logs.len() + 1;
            logs.push(DnsLog {
                id,
                timestamp: Local::now().format("%H:%M:%S").to_string(),
                domain: name_str.clone(),
                record_type: format!("{:?}", record_type),
                status: status.to_string(),
            });
            
            if logs.len() > 1000 {
                logs.remove(0);
            }
        }

        match resolve_result {
            Ok(lookup) => {
                let builder = MessageResponseBuilder::from_message_request(request);
                let mut header = Header::response_from_request(request.header());
                header.set_authoritative(false);
                
                let records: Vec<_> = lookup.record_iter().cloned().collect();
                let response = builder.build(
                    header,
                    records.iter(),
                    std::iter::empty(),
                    std::iter::empty(),
                    std::iter::empty()
                );
                
                return response_handle.send_response(response).await.unwrap_or_else(|_| {
                    let mut fallback_header = Header::response_from_request(request.header());
                    fallback_header.set_response_code(hickory_server::proto::op::ResponseCode::ServFail);
                    fallback_header.into()
                });
            }
            Err(_) => {
                let builder = MessageResponseBuilder::from_message_request(request);
                let mut header = Header::response_from_request(request.header());
                header.set_response_code(hickory_server::proto::op::ResponseCode::ServFail);
                let response = builder.build_no_records(header);
                return response_handle.send_response(response).await.unwrap_or_else(|_| header.into());
            }
        }
    }
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    tracing_subscriber::fmt::init();
    
    let shared_state: SharedState = Arc::new(RwLock::new(Vec::new()));
    
    let app = Router::new()
        .nest_service("/", ServeDir::new("public"))
        .route("/api/reports", get(get_reports))
        .layer(CorsLayer::permissive())
        .with_state(shared_state.clone());
        
    let web_server = tokio::spawn(async move {
        let listener = tokio::net::TcpListener::bind("0.0.0.0:3000").await.unwrap();
        axum::serve(listener, app).await.unwrap();
    });

    let inspector = DnsInspector::new(shared_state);
    let mut server = ServerFuture::new(inspector);
    
    let listen_addr = "127.0.0.1:5300";
    let udp_socket = UdpSocket::bind(listen_addr).await?;
    server.register_socket(udp_socket);
    
    println!("--------------------------------------------------");
    println!("🛡️ DNS Müfettişi ve Dashboard Başlatıldı!");
    println!("📡 DNS Dinleniyor     : udp://{}", listen_addr);
    println!("🌐 Web Arayüzü        : http://localhost:3000");
    println!("🔒 DoH Sağlayıcı      : Cloudflare-HTTPS (1.1.1.1)");
    println!("--------------------------------------------------");
    
    let _ = tokio::try_join!(
        async { server.block_until_done().await.map_err(|e| e.into()) },
        async { web_server.await.map_err(|e| Box::new(e) as Box<dyn std::error::Error>) }
    );
    
    Ok(())
}
